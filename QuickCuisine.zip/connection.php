<?php
$hostname="localhost";
$user_name="root";
$password="947539";
$db="dbfood";
$con=mysqli_connect($hostname,$user_name,$password,$db);

 

?>